let quiz_time = 0;
start_quiz = 0;
quiz_id = 0;
logic_enabled = false;
if (typeof qmn_quiz_data_new !== 'undefined') {
	jQuery.each(qmn_quiz_data_new, function (quiz_id, data) {
		if (data.length > 0) {
			logic_enabled = true;
		}
	})
}

jQuery(document).on('click', '.qmn_mc_answer_wrap', function () {
	if (jQuery(this).find('input[type="radio"]').prop('disabled')) {
		return;
	}
	jQuery(this).parent('.qmn_radio_answers').find('.qmn_mc_answer_wrap').removeClass('qsm-com-checked');
	jQuery(this).addClass('qsm-com-checked');
	jQuery(this).find('input[type="radio"]').prop('checked', true);
	if (logic_enabled) {
		jQuery(this).find('input[type="radio"]').trigger('change');
	}
});
jQuery(document).on('click', '.mlw_horizontal_choice', function () {
	if (jQuery(this).find('input[type="radio"]').prop('disabled')) {
		return;
	}
	jQuery(this).parent('.qmn_radio_answers').find('.mlw_horizontal_choice').removeClass('qsm-com-horizontal-checked');
	jQuery(this).addClass('qsm-com-horizontal-checked');
	jQuery(this).find('input[type="radio"]').prop('checked', true);
	if (logic_enabled) {
		jQuery(this).find('input[type="radio"]').trigger('change');
	}
});
jQuery(document).on('click', '.qsm_check_answer, .mlw_horizontal_multiple', function () {
	if (jQuery(this).find('input[type="checkbox"]').prop('disabled')) {
		return;
	}
	if (jQuery(this).hasClass('qsm-com-horizontal-checked')) {
		jQuery(this).removeClass('qsm-com-horizontal-checked');
		jQuery(this).find('input[type="checkbox"]').prop('checked', false);
	} else {
		jQuery(this).addClass('qsm-com-horizontal-checked');
		jQuery(this).find('input[type="checkbox"]').prop('checked', true);
	}
	if (logic_enabled) {
		jQuery(this).find('input[type="checkbox"]').trigger('change');
	}
});
jQuery(document).on('click', '.qsm_check_answer label, .mlw_horizontal_multiple label', function (e) {
	e.preventDefault();
});

jQuery(document).on('click', '.qmn_accept_answers, .qsm-contact-type-checkbox, .qsm_mailchimp_checkbox_span, .qsm_activecampaign_checkbox_span', function () {
	if (jQuery(this).find('input[type="checkbox"]').prop('checked')) {
		jQuery(this).addClass('qsm-com-horizontal-checked');
	} else {
		jQuery(this).removeClass('qsm-com-horizontal-checked');
	}
});

jQuery(document).on('change', '.qsm_check_answer input[type="checkbox"]', function () {
	if (jQuery(this).prop('checked')) {
		jQuery(this).parents('.qsm_check_answer').addClass('qsm-com-horizontal-checked');
	} else {
		jQuery(this).parents('.qsm_check_answer').removeClass('qsm-com-horizontal-checked');
	}
});

jQuery(document).on('change', '.qmn_mc_answer_wrap input[type="radio"]', function () {
	if (jQuery(this).prop('checked')) {
		jQuery(this).parents('.qmn_mc_answer_wrap').addClass('qsm-com-checked');
	} else {
		jQuery(this).parents('.qmn_mc_answer_wrap').removeClass('qsm-com-checked');
	}
});

jQuery(document).on('change', '.mlw_horizontal_choice input[type="radio"]', function () {
	if (jQuery(this).prop('checked')) {
		jQuery(this).parents('.mlw_horizontal_choice').addClass('qsm-com-horizontal-checked');
	} else {
		jQuery(this).parents('.mlw_horizontal_choice').removeClass('qsm-com-horizontal-checked');
	}
});

jQuery(document).on('qsm_retake_quiz', function (e, quizid) {
	quiz_id = quizid;
	onLoad();
})

jQuery(document).on('qsm_after_file_upload', function (e, container, response) {
	container.find('.pool-file-upload-error').html(response.message).fadeIn();
	container.find('.mlw_file_upload_hidden_value').val(response.file_url);
})

jQuery(document).on('qsm_on_resume_quiz', function (e, element) {
	if (element.parent().hasClass('qmn_mc_answer_wrap')) {
		element.parent().addClass('qsm-com-checked');
	} else {
		element.parent().addClass('qsm-com-horizontal-checked');
	}
});

jQuery(document).ready(function () {
	onLoad();
})

function onLoad() {
	no_featured_image = false;
	if (typeof qsm_featured_image !== 'undefined' && qsm_featured_image.trim().length > 0) {
		jQuery('.quiz_theme_qsm-theme-pool').prepend("<img class='qsm-pool-featured-image' src='" + qsm_featured_image + "'>");
	} else {
		no_featured_image = true;
	}

	if (parseInt(qsm_randomness_order) != 0 && jQuery('.quiz_theme_qsm-theme-pool').find('.qsm-apc-1').length == 0) {
		jQuery('.quiz_theme_qsm-theme-pool').addClass('qsm_random_quiz');
	}

	if (jQuery('.quiz_theme_qsm-theme-pool').find('.qsm-page-1').length || jQuery('.quiz_theme_qsm-theme-pool').find('.qsm-auto-page-row').length) {
		check_pagination = setInterval(function () {
			if (jQuery('.quiz_theme_qsm-theme-pool .qmn_pagination').length > 0) {
				jQuery('.quiz_theme_qsm-theme-pool .qmn_pagination').hide();
				clearInterval(check_pagination);
			}
		}, 10);
		if (no_featured_image) {
			if (!jQuery('.quiz_theme_qsm-theme-pool').hasClass('qsm_random_quiz')) {
				jQuery('.quiz_theme_qsm-theme-pool').addClass('pool-no-container');
				jQuery('.quiz_theme_qsm-theme-pool').find('.quiz_begin').css({
					position: 'relative',
					bottom: '0px'
				});
			}
		}
	}

	if (jQuery('.quiz_theme_qsm-theme-pool').find('.qsm-page-1').length) {
		jQuery('.quiz_theme_qsm-theme-pool').find('.quiz_begin').addClass('qsm-welcome-screen');
	}

	jQuery('.quiz_theme_qsm-theme-pool:not(.qsm_random_quiz) .qsm-auto-page-row.quiz_begin, .quiz_theme_qsm-theme-pool .qsm-welcome-screen').append(
		'<div class="qsm-message-before-footer">' +
		'<a class="qmn_btn mlw_qmn_quiz_link mlw_next" href="#">Next</a>' +
		'</div>'
	);

	jQuery('.quiz_theme_qsm-theme-pool .qsm-welcome-screen .qsm-message-before-footer .mlw_next, .quiz_theme_qsm-theme-pool .qsm-auto-page-row .qsm-message-before-footer .mlw_next').click(function () {
		jQuery(this).parents('.quiz_theme_qsm-theme-pool').find('.qsm-pool-featured-image').hide();
		jQuery(this).parents('.quiz_theme_qsm-theme-pool').find('.qmn_pagination').show();
	});

	jQuery('.quiz_theme_qsm-theme-pool .qsm-welcome-screen .qsm-message-before-footer .mlw_next').click(function () {
		jQuery(this).parents('.quiz_theme_qsm-theme-pool').find('.qmn_pagination .mlw_next').trigger('click');
	});

	jQuery('.quiz_theme_qsm-theme-pool').on('click', '.mlw_next', function () {
		qsm_container = jQuery(this).parents('.quiz_theme_qsm-theme-pool');
		qsm_container.removeClass('pool-no-container');
		quiz_id = jQuery(qsm_container).find('.qmn_quiz_id').val();
		jQuery('.mlw_qmn_timer').hide();
		current = jQuery('.current_page_hidden').val();
		if (qmn_quiz_data[quiz_id].hasOwnProperty('pagination')) {
			total = jQuery('.total_pages_hidden').val();
			if (2 == current) {
				addHeader();
			}

			if (3 == current) {
				jQuery('.mlw_previous').show();
			}
		} else {
			total = Object.keys(qmn_quiz_data[quiz_id].qpages).length;
			if (1 == qmn_quiz_data[quiz_id].contact_info_location) {
				total++;
			}
			if (1 == current) {
				addHeader();
			}

			if (2 == current) {
				jQuery('.mlw_previous').show();
			}
		}

		checkProgressBar(current, total);
		updateTitle();

		if (total == current || (total - current == 1 && jQuery('#quizForm' + quiz_id).closest('.qmn_quiz_container').find('.empty_quiz_end').length == 1)) {
			jQuery('.quiz_theme_qsm-theme-pool .qmn_pagination').width('100%');
			jQuery('.quiz_theme_qsm-theme-pool .qsm-theme-pool-submit-btn').html(jQuery('.quiz_theme_qsm-theme-pool .qsm-submit-btn').val());
			jQuery('.quiz_theme_qsm-theme-pool .qsm-submit-btn').hide();
			jQuery('.quiz_theme_qsm-theme-pool .qsm-theme-pool-submit-btn').show();
		}

	});

	jQuery('.quiz_theme_qsm-theme-pool').on('click', '.mlw_previous', function () {
		current = jQuery('.current_page_hidden').val();
		if (qmn_quiz_data[quiz_id].hasOwnProperty('pagination')) {
			total = jQuery('.total_pages_hidden').val();
			if (1 == current) {
				jQuery('.quiz_theme_qsm-theme-pool .qsm_theme_pool_header').remove();
			}
			if (2 == current) {
				jQuery('.quiz_theme_qsm-theme-pool .mlw_previous').hide();
			}
		} else {
			total = Object.keys(qmn_quiz_data[quiz_id].qpages).length;
			if (1 == qmn_quiz_data[quiz_id].contact_info_location) {
				total++;
			}
			if (0 == current) {
				jQuery('.quiz_theme_qsm-theme-pool .qsm_theme_pool_header').remove();
			}
			if (1 == current) {
				jQuery('.quiz_theme_qsm-theme-pool .mlw_previous').hide();
			}
		}
		jQuery('.quiz_theme_qsm-theme-pool .qsm-theme-pool-submit-btn').hide();
		checkProgressBar(current, total);
		updateTitle();
	});

	jQuery('.quiz_theme_qsm-theme-pool').on('click', '.qsm-theme-pool-submit-btn', function (e) {
		e.preventDefault();
		jQuery('.quiz_theme_qsm-theme-pool .qsm-submit-btn').trigger('click');
	});

	jQuery('.quiz_theme_qsm-theme-pool .qmn_radio_answers .qmn_mc_answer_wrap, .quiz_theme_qsm-theme-pool .qmn_radio_answers .mlw_horizontal_choice').each(function () {
		jQuery(this).prepend('<span class="pool-radio"></span>');
	});

	jQuery('.quiz_theme_qsm-theme-pool .qsm-text-wrong-option, .quiz_theme_qsm-theme-pool .qsm-text-correct-option, .quiz_theme_qsm-theme-pool .qsm-text-simple-option').load(function () {
		jQuery(this).prepend('<span class="pool-radio"></span>');
	});

	jQuery('.quiz_theme_qsm-theme-pool .qmn_check_answers .qsm_check_answer, .quiz_theme_qsm-theme-pool .qmn_check_answers .mlw_horizontal_multiple').each(function () {
		jQuery(this).prepend('<span class="pool-check"></span>');
	});

	jQuery('.quiz_theme_qsm-theme-pool .qsm-contact-type-checkbox .mlw_qmn_question').each(function () {
		jQuery(this).prepend('<span class="pool-check"></span>');
	});

	jQuery('.quiz_theme_qsm-theme-pool .qmn_accept_text').each(function () {
		jQuery('<span class="pool-check"></span>').insertBefore(this);
	});

	jQuery('.quiz_theme_qsm-theme-pool .qsm_activecampaign_label, .quiz_theme_qsm-theme-pool .qsm_mailchimp_label').each(function () {
		jQuery(this).prepend('<span class="pool-check"></span>');
	});

	jQuery('.quiz_theme_qsm-theme-pool .quiz_end').wrapInner('<div class="quiz_end_container"></div>');

	jQuery('.quiz_theme_qsm-theme-pool .mlw_answer_file_upload').each(function () {
		fileUpload = '<div class="pool-file-upload-container">' +
			'<span class="dashicons dashicons-cloud-upload pool-file-upload-logo"></span>' +
			'<div class="pool-file-upload-message"> Drag and Drop File Here or <a class="pool-file-upload-link" href="#">Browse </a>' +
			'</div>' +
			'<div class="pool-file-upload-name"></div>' +
			'<div class="pool-file-upload-error"></div>' +
			'</div>' +
			'</div>';
		jQuery(fileUpload).insertAfter(jQuery(this));
	});

	jQuery('.quiz_theme_qsm-theme-pool .pool-file-upload-container').on('click', function (e) {
		e.preventDefault();
		jQuery(this).prev('.mlw_answer_file_upload').trigger('click');
	});

	jQuery('.mlw_answer_file_upload').on('change', function () {
		jQuery(this).next('.pool-file-upload-container').find('.pool-file-upload-name').html(jQuery(this)[0].files[0].name);
		jQuery(this).next('.pool-file-upload-container').find('.pool-file-upload-error').html('Uploading...').show();
	});

	jQuery('.quiz_theme_qsm-theme-pool .pool-file-upload-container').on(
		'dragover',
		function (e) {
			e.preventDefault();
			e.stopPropagation();
			jQuery(this).addClass('file-hover');
		}
	)
	jQuery('.quiz_theme_qsm-theme-pool .pool-file-upload-container').on(
		'dragenter',
		function (e) {
			e.preventDefault();
			e.stopPropagation();
		}
	)
	jQuery('.quiz_theme_qsm-theme-pool .pool-file-upload-container').on(
		'dragleave',
		function (e) {
			e.preventDefault();
			e.stopPropagation();
			jQuery(this).removeClass('file-hover');
		}
	)
	jQuery('.quiz_theme_qsm-theme-pool .pool-file-upload-container').on(
		'drop',
		function (e) {
			jQuery(this).removeClass('file-hover');
			jQuery(this).find('.pool-file-upload-name').html(e.originalEvent.dataTransfer.files[0].name).fadeIn();
			// jQuery(this).find('.pool-file-upload-error').fadeOut();
			if (e.originalEvent.dataTransfer) {
				if (e.originalEvent.dataTransfer.files.length) {
					e.preventDefault();
					e.stopPropagation();
					jQuery(this).prev('.mlw_answer_file_upload').prop('files', e.originalEvent.dataTransfer.files);
					jQuery(this).prev('.mlw_answer_file_upload').trigger('change');
				}
			}
		}
	);
	jQuery('.quiz_theme_qsm-theme-pool .pool-file-upload-container').on('mouseleave', function () {
		jQuery(this).removeClass('file-hover');
	});

	jQuery('.quiz_theme_qsm-theme-pool').on('click', '.qmn_mc_answer_wrap, .mlw_horizontal_choice', function (e) {
		if (quiz_id === undefined || quiz_id === 0) {
			qsm_container = jQuery(this).parents('.quiz_theme_qsm-theme-pool');
			quiz_id = jQuery(qsm_container).find('.qmn_quiz_id').val();
		}

		// disable change of answers - yes
		if (1 == qmn_quiz_data[quiz_id].disable_answer) {
			if (!jQuery(this).find('input[type="radio"]').prop('disabled')) {
				jQuery(this).addClass('qsm-com-checked');
				jQuery(this).find('input[type="radio"]').prop('checked', true);
				jQuery(this).parents('.qmn_radio_answers').find('input[type="radio"]').prop('disabled', 'disabled');
			}
		}

		question_id = jQuery(this).find('input[type="radio"]').attr('name').split('question')[1],
			value = jQuery(this).find('input[type="radio"]').val()
		selected = jQuery(this);

		// show correct inline
		if (1 == qmn_quiz_data[quizID].enable_quick_result_mc) {
			selected.addClass('pool-wait');
			jQuery.ajax({
				type: 'POST',
				url: qmn_ajax_object.ajaxurl,
				data: {
					action: "qsm_get_question_quick_result",
					question_id: question_id,
					answer: value,
					show_correct_info: qmn_quiz_data[quizID].enable_quick_correct_answer_info
				},
				success: function (response) {
					var data = jQuery.parseJSON(response);
					correctInfo = selected.parents('.qmn_radio_answers').parent().find('.qsm-inline-correct-info').length;
					selected.parents('.qmn_radio_answers').parent().find('.qsm-inline-correct-info').remove();
					selected.parents('.qmn_radio_answers').find('.correct-inline').removeClass('correct-inline pool-wait');
					selected.parents('.qmn_radio_answers').find('.incorrect-inline').removeClass('incorrect-inline pool-wait');
					if (data.success == 'correct') {
						selected.addClass('correct-inline').removeClass('pool-wait');
					} else if (data.success == 'incorrect') {
						selected.addClass('incorrect-inline').removeClass('pool-wait');
					}
					if (data.message != '') {
						selected.parents('.qmn_radio_answers').append("<div class='qsm-inline-correct-info' style='display:none'>" + data.message + "</div>");
						if (correctInfo === 0) {
							jQuery('.qsm-inline-correct-info').fadeIn();
						} else {
							jQuery('.qsm-inline-correct-info').show();
						}
					}

					MathJax.Hub.queue.Push(["Typeset", MathJax.Hub]);
				},
				error: function (errorThrown) {
					alert(errorThrown);
				}
			});
		}

		// end quiz for wrong answer selected option enabled
		if (1 == qmn_quiz_data[quizID].end_quiz_if_wrong) {
			endQuizForWrongAnswer(selected, question_id, value);
		}
	});

	jQuery('.quiz_theme_qsm-theme-pool').on('click', '.qsm_check_answer, .mlw_horizontal_multiple', function (e) {
		if (quiz_id === undefined || quiz_id === 0) {
			qsm_container = jQuery(this).parents('.quiz_theme_qsm-theme-pool');
			quiz_id = jQuery(qsm_container).find('.qmn_quiz_id').val();
		}

		question_id = jQuery(this).find('input[type="checkbox"]').attr('name').split('question')[1],
			value = jQuery(this).find('input[type="checkbox"]').val()
		selected = jQuery(this);

		// end quiz for wrong answer selected option enabled
		if (1 == qmn_quiz_data[quizID].end_quiz_if_wrong) {
			endQuizForWrongAnswer(selected, question_id, value);
		}
	});

	//deselect answers
	jQuery('.quiz_theme_qsm-theme-pool').on('click', '.qsm-deselect-answer', function () {
		jQuery(this).parent().next().children('.qsm-com-checked, .qsm-com-horizontal-checked').each(function () {
			jQuery(this).removeClass('qsm-com-checked qsm-com-horizontal-checked correct-inline incorrect-inline');
		})
	});

	jQuery('.quiz_theme_qsm-theme-pool .ui-slider').on("slidestop", function (event, ui) {
		left_string = jQuery(this).find('.ui-slider-handle').attr('style');
		subStr = left_string.match("left: (.*);");
		left = subStr[1];
		jQuery(this).css({
			background: "linear-gradient( " +
				"90deg, " +
				"rgba(255,255,255, 0) 0%, " +
				qsm_option_color + " " + left + ", " +
				"rgba(255,255,255, 0) 100% " +
				")"
		});

	});

	poolQuizSetup();

	checkHeightForHorizontalElements();
}

function addHeader() {

	header = "<div class='qsm_theme_pool_header'>" +
		"<div class='pool_header_content'>" +
		"<span class='pool_title'></span>" +
		"</div>" +
		"</div>";
	if (0 == jQuery('.qsm_theme_pool_header').length) {
		jQuery(header).insertAfter('#mlw_top_of_quiz');
	}

	if (0 == start_quiz) {
		startTimer();
	}

	if (qmn_quiz_data[quiz_id]['timerRemaning'] > 0) {
		quiz_time = qmn_quiz_data[quiz_id]['timerRemaning'];
	} else if (qmn_quiz_data[quiz_id]['timer_limit_val'] > 0) {
		quiz_time = qmn_quiz_data[quiz_id]['timer_limit_val'] * 60;
	} else {
		quiz_time = 0;
	}
	if (quiz_time == 0) {
		jQuery('.pool_timer').hide();
	} else {
		jQuery('.quiz_theme_qsm-theme-pool .qsm-auto-page-row .quiz_section, .quiz_theme_qsm-theme-pool .qsm-page, .quiz_theme_qsm-theme-pool .quiz_end .quiz_end_container').css(
			{
				'margin-right': '120px ',
				borderRight: '2px solid #13426a10',
				padding: '0px 20px 20px 0'
			}
		);

		timer = "<span class='pool_timer'>" +
			"<div class='base-timer'>" +
			"<svg class='base-timer_svg' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'>" +
			"<g class='base-timer_circle'>" +
			"<circle class='base-timer_path-elapsed' cx='50' cy='50' r='47' />" +
			"<circle class='base-timer_path-remaining' cx='50' cy='50' r='47' />" +
			"</g>" +
			"</svg>" +
			"<span class='pool-timer_label'>Timer" +
			"</span>" +
			"</div>" +
			"<span class='pool-timer_text'>" +
			"</span>" +
			"<span class='pool-timer_text_label'>" +
			"</span>" +
			"</span>";
		jQuery(timer).insertAfter(jQuery('.qsm_theme_pool_header'));
	}

	if_progress_bar = qmn_quiz_data[quiz_id]['progress_bar'];
	if (0 < if_progress_bar && 0 == jQuery('.pool_progress_bar').length) {
		jQuery('.qsm_theme_pool_header').fadeIn(500).css({ 'display': 'flex' });
		jQuery('.pool_header_content').append("<div class='pool_progress_bar'><span class='indicator'></span></div><span class='indicator_text'></span>");

	}

	if (0 == jQuery('.qsm-theme-pool-submit-btn').length) {
		poolSubmit = "<a class='qmn_btn mlw_qmn_quiz_link qsm-theme-pool-submit-btn' href='#' style='display:none;'>Submit</a>";
		jQuery('.quiz_theme_qsm-theme-pool .qmn_pagination').append(poolSubmit);
	}

	jQuery('.mlw_previous').hide();

}

function checkHeightForHorizontalElements() {
	childCount = 0;
	e1 = e2 = {};
	jQuery('.quiz_theme_qsm-theme-pool .qmn_radio_answers .mlw_horizontal_choice, .quiz_theme_qsm-theme-pool .qmn_check_answers .mlw_horizontal_multiple').each(function () {
		childCount++
		if (childCount % 2 == 0) {
			e2 = jQuery(this);
			if (e2.height() > e1.height()) {
				e1.height(e2.height());
			} else {
				e2.height(e1.height());
			}
			e1 = e2 = {};
		} else {
			e1 = jQuery(this);
		}
	});
}

function checkProgressBar(current, total) {
	if (qmn_quiz_data[quiz_id].hasOwnProperty('pagination')) {
		current--;
		total--;
	}
	if (jQuery('#quizForm' + quiz_id).closest('.qmn_quiz_container').find('.empty_quiz_end').length) {
		total--;
	}
	width = parseInt(100 * (current / total));
	width += '%'
	jQuery('.pool_progress_bar .indicator').width(width);
	jQuery('.indicator_text').html(width);
}

function updateTitle() {
	if (qmn_quiz_data[quiz_id].hasOwnProperty('pagination')) {
		current = jQuery('.current_page_hidden').val();
		total = jQuery('.total_pages_hidden').val();
		// will be removed after modification in core
		if (current == total) {
			jQuery('.quiz_theme_qsm-theme-pool .pool_title').html('');
			return;
		}
		title = jQuery('.quiz_theme_qsm-theme-pool .pages_count').html();
		if (title !== undefined) {
			if (0 < title.length) {
				jQuery('.quiz_theme_qsm-theme-pool .pool_title').html('Page ' + title);
			} else {
				jQuery('.quiz_theme_qsm-theme-pool .pool_title').html('');
			}
		}

	} else {
		title = jQuery('.quiz_theme_qsm-theme-pool .qsm-page:visible .pages_count').html();
		if (title !== undefined) {
			jQuery('.quiz_theme_qsm-theme-pool .pool_title').html('Page ' + title);
		} else {
			jQuery('.quiz_theme_qsm-theme-pool .pool_title').html('');
		}
	}
}

function poolQuizSetup() {
	jQuery('.quiz_theme_qsm-theme-pool .question-type-polar-s').each(function () {
		sliderWrapper = jQuery(this).find('.slider-main-wrapper');
		console.log(sliderWrapper.find('.ui-slider'));
		sliderWrapper.find('.ui-slider').css({
			background: "linear-gradient( " +
				"90deg, " +
				"rgba(255,255,255, 0) 0%, " +
				qsm_option_color + " 50% , " +
				"rgba(255,255,255, 0) 100% " +
				")"
		});
	});

	jQuery('.quiz_theme_qsm-theme-pool .mlw_qmn_question_number').each(function () {
		if (jQuery(this).next().hasClass('qsm-featured-image')) {
			number = jQuery(this);
			jQuery(number).insertAfter(jQuery(this).next());
		}
	});
}

function endQuizForWrongAnswer(option, question_id, value) {
	option.addClass('pool-wait');
	container = option.parents('.qmn_quiz_container');
	jQuery.ajax({
		type: 'POST',
		url: qmn_ajax_object.ajaxurl,
		data: {
			action: "qsm_get_question_quick_result",
			question_id: question_id,
			answer: value,
			show_correct_info: qmn_quiz_data[quizID].enable_quick_correct_answer_info
		},
		success: function (response) {
			var data = jQuery.parseJSON(response);
			correctInfo = option.parent().find('.qsm-inline-correct-info').length;
			if (data.success == 'incorrect') {
				option.addClass('incorrect-inline');
				if (data.message != '') {
					option.parent().append("<div class='qsm-inline-correct-info' style='display:none'>" + data.message + "</div>");
					if (correctInfo === 0) {
						jQuery('.qsm-inline-correct-info').fadeIn();
					} else {
						jQuery('.qsm-inline-correct-info').show();
					}
				}
				setTimeout(function () {
					container.find('.qsm-submit-btn').trigger('click');
				}, 1000);
			}
			option.removeClass('pool-wait');
		},
		error: function (errorThrown) {
			alert(errorThrown);
		}
	});
}

function formatTimeLeft(time) {
	time_label = '';
	minutes = Math.floor(time / 60);
	if (60 <= minutes) {
		hours = Math.floor(minutes / 60);
		minutes = minutes % 60;
		time_label = hours + ':' + minutes.toString().padStart(2, '0');
		jQuery('.pool-timer_text_label').html('HOURS')
		calculateStrokeArray(time % 60);
	} else if (minutes > 0) {
		seconds = time % 60;
		time_label = minutes + ':' + seconds.toString().padStart(2, '0');
		jQuery('.pool-timer_text_label').html('MINUTES')
		calculateStrokeArray(seconds);
	} else {
		time_label = time;
		jQuery('.pool-timer_text_label').html('SECONDS')
		calculateStrokeArray(time);
	}

	if (minutes == 0) {
		changeColor(time);
	}

	return time_label;
}

function calculateStrokeArray(seconds) {
	fraction = (seconds) / 60 * 295
	strokeDashArray = fraction.toFixed(0) + ' 295';
	jQuery('.base-timer_path-remaining').css('stroke-dasharray', strokeDashArray);
}

function changeColor(time) {
	if (time > 30 && time <= 45) {
		jQuery('.base-timer_path-remaining').css('stroke', '#00C2FF');
	} else if (time > 15 && time <= 30) {
		jQuery('.base-timer_path-remaining').css('stroke', '#FFB800');
	} else if (time <= 15) {
		jQuery('.base-timer_path-remaining').css('stroke', '#FF5555');
	} else {
		jQuery('.base-timer_path-remaining').css('stroke', '#1DD969');
	}
}

function startTimer() {
	if (start_quiz == 0) {
		timerInterval = setInterval(() => {
			quiz_time--;
			jQuery('.pool-timer_text').html(formatTimeLeft(quiz_time));
			if (quiz_time == 0) {
				clearInterval(timerInterval);
			}
		}, 1000);
	}
	start_quiz++;
}

