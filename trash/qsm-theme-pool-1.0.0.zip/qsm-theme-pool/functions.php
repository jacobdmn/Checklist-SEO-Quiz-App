<?php

/**
 * Include style and script for quiz theme
 */
add_action( 'qsm_enqueue_script_style', 'qsm_theme_quiz_pool_style' );
if ( ! function_exists( 'qsm_theme_quiz_pool_style' ) ) {
	function qsm_theme_quiz_pool_style( $qmn_quiz_options ) {
		global $mlwQuizMasterNext;
		$quiz_id              = $qmn_quiz_options->quiz_id;
		$featured_image       = get_option( "quiz_featured_image_$quiz_id" );
		$saved_quiz_theme     = $mlwQuizMasterNext->theme_settings->get_active_quiz_theme_path( $quiz_id );
		$quiz_settings        = unserialize( $qmn_quiz_options->quiz_settings );
		$get_saved_quiz_theme = isset( $quiz_settings['quiz_new_theme'] ) ? $quiz_settings['quiz_new_theme'] : '';
		$progress_bar         = $qmn_quiz_options->progress_bar;
		$folder_slug          = QSM_THEME_SLUG . $saved_quiz_theme;
		wp_enqueue_script( 'qsm_theme_pool_js', plugin_dir_url( __FILE__ ) . 'qsm_theme.js', array( 'jquery' ) );
		if ( ! empty( $featured_image ) ) {
			wp_localize_script( 'qsm_theme_pool_js', 'qsm_featured_image', $featured_image );
		}
		$randomness_order = $qmn_quiz_options->randomness_order;
		wp_localize_script( 'qsm_theme_pool_js', 'qsm_randomness_order', $randomness_order );
		?>
<link rel="stylesheet" href="<?php echo $folder_slug . '/style.css'; ?>" media="all">
<?php
		$theme_id           = $mlwQuizMasterNext->theme_settings->get_active_quiz_theme( $quiz_id );
		$get_theme_settings = $mlwQuizMasterNext->theme_settings->get_active_theme_settings( $quiz_id, $theme_id );
		$color_data         = array();
		foreach ( $get_theme_settings as $data ) {
			$color_data[ $data['id'] ] = $data['default'];
		}
		$get_theme_settings     = $color_data;
		$background_color       = isset( $get_theme_settings['background_color'] ) && $get_theme_settings['background_color'] != '' ? $get_theme_settings['background_color'] : '';
		$button_color           = isset( $get_theme_settings['button_color'] ) && $get_theme_settings['background_color'] != '' ? $get_theme_settings['button_color'] : '';
		$progressbar_color      = isset( $get_theme_settings['progressbar_color'] ) && $get_theme_settings['progressbar_color'] != '' ? $get_theme_settings['progressbar_color'] : '';
		$progressbar_background = isset( $get_theme_settings['progressbar_background'] ) && $get_theme_settings['progressbar_background'] != '' ? $get_theme_settings['progressbar_background'] : '';
		$option_color           = isset( $get_theme_settings['option_color'] ) && $get_theme_settings['option_color'] != '' ? $get_theme_settings['option_color'] : '';
		if ( ! empty( $option_color ) ) {
			wp_localize_script( 'qsm_theme_pool_js', 'qsm_option_color', $option_color );
		}
		$font_color = isset( $get_theme_settings['font_color'] ) && $get_theme_settings['font_color'] != '' ? $get_theme_settings['font_color'] : '';
		?>
<style type="text/css">
<?php if ($button_color) {
	?>.quiz_theme_qsm-theme-pool .quiz_section .mlw_qmn_hint_link {
		color:
			<?php echo $button_color;
		?> !important;
	}

	.quiz_theme_qsm-theme-pool .pool-file-upload-logo,
	.quiz_theme_qsm-theme-pool .pool-file-upload-message a,
	.quiz_theme_qsm-theme-pool .mlw_pool_previous .dashicons {
		color:
			<?php echo $button_color;
		?>;
	}

	.quiz_theme_qsm-theme-pool .pool-file-upload-container.file-hover,
	.quiz_theme_qsm-theme-pool .pool-file-upload-container:hover {
		border-color:
			<?php echo $button_color;
		?> !important;
	}

	.quiz_theme_qsm-theme-pool .pool-file-upload-container.file-hover {
		background-color:
			<?php echo $button_color . '10';
		?> !important;
	}

	<?php
}

?><?php if ($progressbar_color) {
	?>.quiz_theme_qsm-theme-pool .qsm_theme_pool_header .pool_progress_bar .indicator {
		background:
			<?php echo $progressbar_color;
		?>;
	}

	.quiz_theme_qsm-theme-pool .qsm-progress-bar svg path:nth-child(2) {
		stroke:
			<?php echo $progressbar_color;
		?> !important;
	}

	.quiz_theme_qsm-theme-pool .qsm-progress-bar .progressbar-text {
		color:
			<?php echo $progressbar_color;
		?> !important;
	}

	<?php
}

?><?php if ($progressbar_background) {

	?>.quiz_theme_qsm-theme-pool .qsm-welcome-screen,
	.quiz_theme_qsm-theme-pool:not(.qsm_random_quiz) .qsm-auto-page-row.quiz_begin,
	.quiz_theme_qsm-theme-pool .qsm_theme_pool_header {
		background:
			<?php echo $progressbar_background;
		?>;
	}

	<?php
}

?><?php if ($option_color) {

	?>.quiz_theme_qsm-theme-pool .qmn_radio_answers .qsm-com-checked .pool-radio,
	.quiz_theme_qsm-theme-pool .qmn_radio_answers .qsm-com-horizontal-checked .pool-radio,
	.quiz_theme_qsm-theme-pool .qsm-com-horizontal-checked .pool-check,
	.quiz_theme_qsm-theme-pool .qmn_radio_answers .qmn_mc_answer_wrap:hover .pool-radio,
	.quiz_theme_qsm-theme-pool .qmn_check_answers .qsm_check_answer:hover .pool-check,
	.quiz_theme_qsm-theme-pool .qmn_check_answers .mlw_horizontal_multiple:hover .pool-check,
	.quiz_theme_qsm-theme-pool .mlw_horizontal_choice:hover .pool-radio,
	.quiz_theme_qsm-theme-pool .slider-main-wrapper .ui-slider .ui-slider-handle {
		border-color:
			<?php echo $option_color;
		?> !important;
	}

	.quiz_theme_qsm-theme-pool .qmn_image_option.qsm-com-checked .qsm_image_caption,
	.quiz_theme_qsm-theme-pool .qmn_radio_answers .qsm-com-horizontal-checked .pool-radio:before,
	.quiz_theme_qsm-theme-pool .qmn_radio_answers .qsm-com-checked .pool-radio:before,
	.quiz_theme_qsm-theme-pool .qsm-com-horizontal-checked .pool-check,
	.quiz_theme_qsm-theme-pool .qmn_check_answers .qsm-com-horizontal-checked .pool-check,
	.quiz_theme_qsm-theme-pool .qmn_accept_answers.qsm-com-horizontal-checked .pool-check,
	.quiz_theme_qsm-theme-pool .ui-slider-handle {
		background:
			<?php echo $option_color;
		?> !important;
	}

	.quiz_theme_qsm-theme-pool .quiz_section .qmn_image_option:hover,
	.quiz_theme_qsm-theme-pool .qmn_image_option.qsm-com-checked {
		border-color:
			<?php echo $option_color;
		?> !important;
	}

	<?php
}

?><?php if ($font_color) {

	?>

	/* .qsm-quiz-container.quiz_theme_qsm-theme-pool .mlw_qmn_message_before, */
	body .quiz_theme_qsm-theme-pool .quiz_section,
	.question-type-polar-s .left-polar-title,
	.question-type-polar-s .right-polar-title,
	.quiz_theme_qsm-theme-pool select,
	.quiz_theme_qsm-theme-pool .mlw_answer_date,
	.quiz_theme_qsm-theme-pool .mlw_answer_file_upload,
	.quiz_theme_qsm-theme-pool .quiz_end,
	.quiz_theme_qsm-theme-pool .qsm-text-simple-option,
	.quiz_theme_qsm-theme-pool .qsm-text-correct-option,
	.quiz_theme_qsm-theme-pool .qsm-text-wrong-option {
		color:
			<?php echo $font_color;
		?> !important;
	}

	.quiz_theme_qsm-theme-pool .qmn_radio_answers .qmn_mc_answer_wrap,
	.quiz_theme_qsm-theme-pool .qmn_check_answers .qsm_check_answer,
	.qsm-quiz-container.quiz_theme_qsm-theme-pool .quiz_section .mlw_qmn_new_question,
	.quiz_theme_qsm-theme-pool .quiz_section .mlw_qmn_question.qsm_remove_bold,
	.quiz_theme_qsm-theme-pool span.pages_count {
		color:
			<?php echo $font_color;
		?>;
	}

	.qsm-quiz-container.quiz_theme_qsm-theme-pool .qmn_multiple_horizontal_check .mlw_horizontal_multiple,
	.qsm-quiz-container.quiz_theme_qsm-theme-pool .mlw_horizontal_choice {
		color:
			<?php echo $font_color;
		?>;
	}

	<?php
}

?><?php if ($background_color) {
	?>.quiz_theme_qsm-theme-pool.qsm-quiz-container {
		background:
			<?php echo $background_color;
		?>;
	}

	.quiz_theme_qsm-theme-pool .qsm-welcome-screen div,
	.quiz_theme_qsm-theme-pool .qsm-welcome-screen .mlw_qmn_message_before,
	.quiz_theme_qsm-theme-pool:not(.qsm_random_quiz) .qsm-auto-page-row.quiz_begin,
	.quiz_theme_qsm-theme-pool:not(.qsm_random_quiz) .qsm-auto-page-row.quiz_begin .mlw_qmn_message_before>* {
		color:
			<?php echo $background_color;
		?> !important;

	}

	<?php
}

?>.quiz_theme_qsm-theme-pool .incorrect-inline .pool-check,
.quiz_theme_qsm-theme-pool .incorrect-inline .pool-radio,
.quiz_theme_qsm-theme-pool .correct-inline .pool-check,
.quiz_theme_qsm-theme-pool .correct-inline .pool-radio,
.quiz_theme_qsm-theme-pool .pool-wait .pool-check,
.quiz_theme_qsm-theme-pool .pool-wait .pool-radio {
	border: none !important;
}

.quiz_theme_qsm-theme-pool .qmn_image_option.correct-inline .qsm_image_caption {
	background: #1dd969 !important;
}

.quiz_theme_qsm-theme-pool .qmn_image_option.incorrect-inline .qsm_image_caption {
	background: #ff5555 !important;
}
</style>
<?php
	}
}

add_filter( 'qmn_begin_shortcode', 'pool_footer', 10, 3 );
if ( ! function_exists( 'pool_footer' ) ) {
	function pool_footer( $return_display, $qmn_quiz_options, $qmn_array_for_variables ) {
		global $mlwQuizMasterNext;
		$saved_quiz_theme = $mlwQuizMasterNext->quiz_settings->get_setting( 'quiz_new_theme' );
		$quiz_settings    = unserialize( $qmn_quiz_options->quiz_settings );
		return $return_display;
	}
}