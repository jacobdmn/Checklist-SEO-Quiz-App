<?php
/**
 * Plugin Name: QSM Theme - Pool
 * Plugin URI: https://quizandsurveymaster.com
 * Description: Adds Pool theme for Quiz Master Quizzes
 * Author: QSM Team
 * Author URI: https://quizandsurveymaster.com
 * Version: 1.0.0
 *
 * @author QSM Team
 * @version 1.0.0
 */

class QSM_Theme_Pool {

	/**
	 * Version Number
	 *
	 * @var string
	 * @since 1.0.0
	 */
	public $version = '1.0.0';

	public function __construct() {
		$this->load_dependencies();
		$this->check_license();
		$this->add_hooks();
	}

	public function load_dependencies() {
		include 'php/addon-settings-tab-content.php';
	}

	/**
	 * Add Hooks
	 *
	 * Adds functions to relavent hooks and filters
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function add_hooks() {
		add_action( 'admin_init', 'qsm_addon_theme_pool_register_stats_tabs' );
	}

	/**
	 * Checks license
	 *
	 * Checks to see if license is active and, if so, checks for updates
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function check_license() {

		if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
			// Loads our custom updater.
			include 'php/EDD_SL_Plugin_Updater.php';
		}

		// Retrieves our license key from the DB.
		$theme_data = get_option( 'qsm_addon_theme_settings', '' );
		if ( isset( $theme_data['license_key'] ) ) {
			$license_key = trim( $theme_data['license_key'] );
		} else {
			$license_key = '';
		}

		// Sets up the updater.
		$edd_updater = new EDD_SL_Plugin_Updater(
			'https://quizandsurveymaster.com',
			__FILE__,
			array(
				'version'   => $this->version,
				'license'   => $license_key,
				'item_name' => 'Pool', // need to be changed
				'author'    => 'QSM Team', // need to be changed
			)
		);
	}

	public static function default_setting() {
		$settings   = array();
		$settings[] = array(
			'id'      => 'background_color',
			'label'   => __( 'Background Color' ),
			'type'    => 'color',
			'default' => '#FFFFFF',
		);
		$settings[] = array(
			'id'      => 'button_color',
			'label'   => __( 'Button Color' ),
			'type'    => 'color',
			'default' => '#1BC8F1',
		);
		$settings[] = array(
			'id'      => 'progressbar_color',
			'label'   => __( 'Progressbar Color' ),
			'type'    => 'color',
			'default' => '#1BC8F1',
		);
		$settings[] = array(
			'id'      => 'progressbar_background',
			'label'   => __( 'Progressbar Background Color' ),
			'type'    => 'color',
			'default' => '#004CD0',
		);
		$settings[] = array(
			'id'      => 'option_color',
			'label'   => __( 'Option Hover Color' ),
			'type'    => 'color',
			'default' => '#1BC8F1',
		);
		$settings[] = array(
			'id'      => 'font_color',
			'label'   => __( 'Font Color' ),
			'type'    => 'color',
			'default' => '#222',
		);
		return serialize( $settings );
	}
}

add_action( 'plugins_loaded', 'qsm_addon_pool_load' );

/**
 * Checks if QSM version 7.2.0 or above is installed
 *
 * @since 1.0.0
 * @return void
 */
function qsm_addon_pool_load() {
	$deactivate = true;
	if ( class_exists( 'MLWQuizMasterNext' ) ) {
		global $mlwQuizMasterNext;
			$current_version = $mlwQuizMasterNext->version;
		if ( version_compare( $current_version, '7.2.0', '>=' ) ) {
			new QSM_Theme_Pool();
			$deactivate = false;
		} else {
			add_action( 'admin_notices', 'qsm_addon_pool_version_qsm' );
		}
	} else {
		add_action( 'admin_notices', 'qsm_addon_pool_missing_qsm' );
	}
	if ( $deactivate ) {
		include_once ABSPATH . 'wp-admin/includes/plugin.php';
		$dir  = basename( dirname( __FILE__ ) );
		$file = basename( __FILE__ );
		deactivate_plugins( $dir . '/' . $file );
	}
}

/**
 * Generates admin notice if QSM is not installed
 *
 * @since 1.0.0
 * @return void
 */
function qsm_addon_pool_missing_qsm() {
	echo '<div class="error"><p>QSM - Themes requires Quiz And Survey Master. Please install and activate the Quiz And Survey Master plugin.</p></div>';
}

/**
 * Genereates admin notice if installed QSM in below 7.2.0
 *
 * @return void
 */
function qsm_addon_pool_version_qsm() {
	echo '<div class="error"><p>QSM - Themes requires at least Quiz And Survey Master V 7.2.0. Please update and reinstall</p></div>';
}

/**
 * Updates theme and default settings
 */
register_activation_hook(
	__FILE__,
	function () {
		if ( class_exists( 'MLWQuizMasterNext' ) ) {
			global $mlwQuizMasterNext;
				$current_version = $mlwQuizMasterNext->version;
			if ( version_compare( $current_version, '7.2.0', '>=' ) ) {
				$name     = 'Pool';
				$settings = QSM_Theme_Pool::default_setting();
				$dir      = basename( dirname( __FILE__ ) );
				$mlwQuizMasterNext->theme_settings->update_theme_status( true, $dir, $name, $settings );
			}
		}
	}
);

/**
 * Deactivates theme
 */
register_deactivation_hook(
	__FILE__,
	function () {
		if ( class_exists( 'MLWQuizMasterNext' ) ) {
			global $mlwQuizMasterNext;
				$current_version = $mlwQuizMasterNext->version;
			if ( version_compare( $current_version, '7.2.0', '>=' ) ) {
				$dir = basename( dirname( __FILE__ ) );
				$mlwQuizMasterNext->theme_settings->update_theme_status( false, $dir );}
		}
	}
);